Name: Alexander Guo
NetID: aguo7
ACC: aguo

Spring 2018 CS342
Professor John Bell


just type make and you will have your program
to run it, type:
     java ExamDriver
I've included javadocs, to see those go to the docs directory
and open package-summary.html with your favorite browser
    
